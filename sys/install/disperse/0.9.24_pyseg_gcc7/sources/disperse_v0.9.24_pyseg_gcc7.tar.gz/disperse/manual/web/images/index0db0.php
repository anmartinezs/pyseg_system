<?xml version="1.0" encoding="UTF-8"?>
<rsd version="1.0" xmlns="http://archipelago.phrasewise.com/rsd">
<service>
  <engineName>Dotclear</engineName>
  <engineLink>http://www.dotclear.org/</engineLink>
  <homePageLink>http://localhost/dotclear/index.php?</homePageLink>
</service>
</rsd>
